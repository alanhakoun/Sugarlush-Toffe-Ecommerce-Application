# Software Assignment 2 & 3 
 
## Group Team
| Name | ID | Email |
|------|----|-------|
| Sara Tamer Mohamed Bihery | 20210155 | sasooelbihery@gmail.com |
| Sohaila Abdelazim Khalifa | 20210492 | Sohailakhalifa03@gmail.com |
| Alan Samir Hakoun  | 20210755 | alanhakoun@gmail.com |

# Sugarlush - Toffe Ecommerce Application Projcet 
This repository contains the source code for an ecommerce application developed using Java.
The application allows users to view and purchase products, manage their account, and cancel the order.

# Files Included
- src: Contains the Java source code for the application
- lib: Contains external libraries used by the application for sending OTP 
- text files: Contains user and catalog database
- README.txt: This file, explaining the contents of the repository

# Tools Used
The toffee application was developed using the following tools:

- Java SE Development

The external libraries used by the application include:
- javax.activation
- sun.mail.javax
- twilio.sdk

# Support
If you encounter any issues while using the ecommerce application, please create an issue in this repository and we will do our best to help you.